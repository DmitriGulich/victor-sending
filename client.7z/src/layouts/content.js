import React from 'react';



const Content = () => {
    return ( 
        <div>Content</div>
     );
}
 
export default Content;