import React from 'react';
import axios from 'axios';

import RegisterForm from './forms/registerForm';

const Register = () => {

    const onSubmit = (values) => {
        console.log(values);
        return axios.post('/auth/register', values,  {headers: {
            "Content-Type": "application/json",
          }})
            .then(response => consoloe.log(response))
            .catch(error => consoloe.log(error));
    }

    return ( 
        <div>
            <RegisterForm onSubmit={onSubmit} />
        </div>
     );
}
 
export default Register;