import React, { useEffect, useState } from 'react';
import { Redirect } from 'react-router';

const Login = () => {
    
    const [auth, setAuth] = useState(true);

    return ( 
        <div>
            {auth ? <Redirect to="/" /> : <div>Login</div>}
        </div>
     );
}
 
export default Login;