import React from 'react';
import Content from './layouts/content';
import Footer from './layouts/footer';
import Header from './layouts/header';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import Register from './components/auth/register';
import Login from './components/auth/login';
import VerifyEmail from './components/auth/forms/verifyEmail';


const App = () => {
    return ( 
            <div className="container">
                <Header />
                <Switch>
                    <Route path="/" exact component={Content} />
                    <Route path="/register" exact component={Register} />
                    <Route path="/mailVerify" exact component={VerifyEmail} />
                    <Route path="/login" exact component={Login} />
                </Switch>
                <Footer />
            </div>
     );
}
 
export default App;