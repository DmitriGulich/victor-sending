export const LOGGED_IN = 'LOGGED_IN';
export const LOG_OUT = 'LOG_OUT';
export const VERIFY_USER = 'VERIFY_USER';